<?php
require "connection.php";
//CREATE TABLE `kasukupro`.`bac 1102 attendance` ( `REGNO` VARCHAR(10) NOT NULL , PRIMARY KEY (`REGNO`)) ENGINE = MyISAM;
//ALTER TABLE `bac 1101 attendance` ADD `STUDENT_NAME` VARCHAR(50) NOT NULL AFTER `REGNO`;
//ALTER TABLE `bac_1102_attendance` ADD `22-August-2020` VARCHAR(10) NULL DEFAULT 'ABSENT';

echo strtoupper(date('jS\-F\-Y'));

?>