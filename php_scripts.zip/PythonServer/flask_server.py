import os
import flask
import werkzeug
import re
import string
from flask import Flask, request

#do imports
#import matplotlib for drawing images
from matplotlib import pyplot as plt
import tensorflow.keras as keras
#import mtcnn library (Multi-task Cascade Convolutional Neural Network)
#MTCNN is used for face detection
from mtcnn.mtcnn import MTCNN
print('loading MTCNN to extract face boundaries \n')
detector = MTCNN()
### Extract Face for Further Analysis
from numpy import asarray
from PIL import Image
#imports
from keras_vggface.utils import preprocess_input
from scipy.spatial.distance import cosine
#create vggface2 model
from keras_vggface.vggface import VGGFace
vgg_model = VGGFace(model='resnet50')

app = Flask(__name__)
#the home page / root
@app.route('/', methods=['GET', 'POST'])
def handle_request():
	try:
		#uploaded files are stored into the “flask.request.files” dictionary
		#get the field name of the passed message
		imagefile = flask.request.files['image']
		#get the file name
		filename = werkzeug.utils.secure_filename(imagefile.filename)
		#allow only digits and letters in the filename
		allow = string.ascii_letters + string.digits
		#substitute any other letter with blank string
		filename = re.sub('[^%s]' % allow, '', filename) + '.jpg'
		#
		print("\nReceived image File name : " + imagefile.filename)
		#save image to the kasukupro/photos folder
		imagefile.save(os.path.join('C:\\wamp64\\www\\kasukupro\\PythonServer\\photos',filename))
		#
		return "Image Uploaded Successfully"
	except Exception as e:
		print(e)
		return "Flask 1: A Server Error Occured"
	
#another page    
@app.route("/salvador")
def salvador():
    return "Hello, Salvador"
	
#page to verify photos    
@app.route("/verify",methods=['GET', 'POST'])
def face_verification():
	try:
		#get the passed regno
		regno = request.form.get('REGNO')
		#initialize photo paths
		print('initializing photo paths')
		known_image = "C:\\wamp64\\www\\kasukupro\\PythonServer\\photos\\" + regno + '.jpg'
		test_image = "C:\\wamp64\\www\\kasukupro\\PythonServer\\photos\\" + regno + 'test.jpg'		
		#get face extracts
		known_face_extract = extract_face_from_photo(known_image)
		test_face_extract = extract_face_from_photo(test_image)
		#putting the functions together
		known_face_embedding = get_face_embeddings(known_face_extract)
		test_face_embedding = get_face_embeddings(test_face_extract)
		#check if its a match
		result = is_match(known_face_embedding,test_face_embedding,thresh=0.45)
		#
		return result
		
	except Exception as e:
		print(e)
		return "Flask 2: A Server Error Occured"
		
#function to extract faces from a photo
def extract_face_from_photo(image_path, required_size=(224, 224)):
  # load image and detect faces
    image = plt.imread(image_path)
    #get coordinates of the faces in the photo
    faces = detector.detect_faces(image)
    #list to hold faces found in the photo
    found_faces = []
    
    for face in faces:
        # extract the bounding box for requested face
        x1, y1, width, height = face['box']
        x2 = x1 + width
        y2 = y1 + height
        print('face coordinates extracted')
        # extract the face (an image crop operation)
        #variable image is a numpy n directional array
        face_boundary = image[y1:y2, x1:x2]
        print('face cropped from original photo')
        # resize pixels to the model size
        #first convert ndarray to a pillow image
        face_image = Image.fromarray(face_boundary)
        face_image = face_image.resize(required_size)
        #convert back to array
        face_array = asarray(face_image)
        found_faces.append(face_array)

    return found_faces
	
def get_face_embeddings(faces):
    samples = asarray(faces, 'float32')

    # prepare the data for the model using vggface2
    samples = preprocess_input(samples, version=2)

    # perform prediction of face embedding
    return vgg_model.predict(samples)
	
# determine if a candidate face is a match for a known face
def is_match(known_embedding, candidate_embedding, thresh):
	# calculate distance between embeddings
	print('calculating distance btn face embeddings')
	print('\n')
	result=''
	score = cosine(known_embedding, candidate_embedding)
	if score <= thresh:
		print('face is a match')
		result = 'face is a match'
	else:
		print('face is NOT a Match')
		result = 'face is NOT a match'
	return result
    
if __name__ == "__main__":
    app.run(host='0.0.0.0', port=5000,debug=True)