known_image = "C:\\wamp\\www\\kasukupro\\PythonServer\\photos\\1805866.jpg"
test_image = "C:\\wamp\\www\\kasukupro\\PythonServer\\photos\\1805866test.jpg"

root_path = 'C:\\wamp\\www\\kasukupro\\PythonServer\\photos'

#do imports
#import matplotlib for drawing images
from matplotlib import pyplot as plt
import tensorflow.keras as keras
#import mtcnn library (Multi-task Cascade Convolutional Neural Network)
#MTCNN is used for face detection
from mtcnn.mtcnn import MTCNN

### Extract Face for Further Analysis
from numpy import asarray
from PIL import Image

print('\n')
print('loading MTCNN to extract face boundaries')
print('\n')
detector = MTCNN()

#function to extract faces from a photo
def extract_face_from_photo(image_path, required_size=(224, 224)):
  # load image and detect faces
    image = plt.imread(image_path)
    #get coordinates of the faces in the photo
    faces = detector.detect_faces(image)
    #list to hold faces found in the photo
    found_faces = []
    
    for face in faces:
        # extract the bounding box for requested face
        x1, y1, width, height = face['box']
        x2 = x1 + width
        y2 = y1 + height
        print('face coordinates extracted')
        # extract the face (an image crop operation)
        #variable image is a numpy n directional array
        face_boundary = image[y1:y2, x1:x2]
        print('face cropped from original photo')
        # resize pixels to the model size
        #first convert ndarray to a pillow image
        face_image = Image.fromarray(face_boundary)
        face_image = face_image.resize(required_size)
        #convert back to array
        face_array = asarray(face_image)
        found_faces.append(face_array)

    return found_faces

#get face extracts
known_face_extract = extract_face_from_photo(known_image)
test_face_extract = extract_face_from_photo(test_image)
'''
# Display the the extracted faces
plt.subplot(1,2,1)
plt.imshow(known_face_extract[0])
#create a separation between the columns
plt.tight_layout()

plt.subplot(1, 2, 2)
plt.imshow(test_face_extract[0])

plt.show()
'''
#2.1 Compare Two Faces

#imports
from keras_vggface.utils import preprocess_input
from keras_vggface.vggface import VGGFace
from scipy.spatial.distance import cosine

#vggface2 is a model trained on millions of photos for face identification
#the model returns a face embedding on calling its predict function
#face embedding is a vector that represents the features extracted from the face

print('\n')
print('loading the VGGFace2 model to predict face embeddings')
print('\n')
#load the model
from tensorflow.keras.models import load_model
vgg_model = load_model("C:\\KasukuPro\\vggface2.h5",compile=False)
    
def get_face_embeddings(faces):
    samples = asarray(faces, 'float32')

    # prepare the data for the model using vggface2
    samples = preprocess_input(samples, version=2)

    # perform prediction of face embedding
    return vgg_model.predict(samples)

#################################################
#verification is a comparison of face embeddings
#it is performed by calculating the Cosine distance 
#between the embedding for the known identity and the embeddings of candidate face


# determine if a candidate face is a match for a known face
def is_match(known_embedding, candidate_embedding, thresh):
	# calculate distance between embeddings
	print('calculating distance btn face embeddings')
	print('\n')
	score = cosine(known_embedding, candidate_embedding)
	if score <= thresh:
		print('face is a match')
		print('with a score of: ',round(score,2))
		print('cosine thresh-hold used is: ',thresh)
	else:
		print('face is NOT a Match')
		print('with a score of: ',round(score,2))
		print('cosine thresh-hold used is: ',thresh)
  
#putting the functions together
known_face_embedding = get_face_embeddings(known_face_extract)
test_face_embedding = get_face_embeddings(test_face_extract)

#check if its a match
is_match(known_face_embedding,test_face_embedding,thresh=0.45)
